const otak = (prefix, pushname) => {
    return `*Palabras especificas para que el bot interactue con ustedes mis queridos otakus*


quien es tu sempai botsito
me gimes 7u7
te amo botsito uwu
onichan
la toca 7w7


_Ojito escribe tal como esta_

ву ѕнαη∂υу`

}

exports.otak = otak
