const antimenu = (prefix, pushname) => {
    return `
*Comandos Para Activar El Antilink ⚠*

*PARA ACTIVAR EL ANTILINK*
${prefix}antilink 1

*PARA DESACTIVAR EL ANTILINK*
${prefix}antilink 0

_Para activar este comando el bot necesita tener admin y esta funcion solo la activan los admins del grupo_

ву ѕнαη∂υу
`

}

exports.antimenu = antimenu
