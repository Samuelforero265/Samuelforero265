const help = (prefix) => {
	return `

⌜ *ѕнαηвσт ву ѕнαη∂υу* ⌟  

◉ *INFORMACION*
   ○ Comando: ⌜ ${prefix} ⌟
   ○ Creador: ѕнαη∂υу™ 
   ○ Como instalar el bot: https://www.youtube.com/watch?v=2LQSzEbpJ-M
   ○ Instagram: https://www.instagram.com/thepavos


◉ *NUEVOS COMANDOS*
○ ${prefix}antimenu
Su nombre lo dice todo (antilink)
○ ${prefix}otak
Monas chinas
○ ${prefix}shantera
Interactua con el bot

◉ *NUEVOS MENUS*
○ ${prefix}juegos
Divierte con tus amigos :)
○ ${prefix}desmenu
Descargar musica y videos de YT
○ ${prefix}version
Conoce la versión de tu bot
○ ${prefix}welmenu
Comandos de bienvedia a grupos

◉ *PARA USAR EL BOT*
Registrate con el comando ${prefix}daftar y tu nombre

◉ *RESUELVE TUS DUDAS*
  ║
  ╠ ○ ${prefix}creador
  ╚ Dudas o problemas aqui

◉ *CREAR STICKERS*
  ║
  ╠ ○ ${prefix}sticker
  ╠ ○ ${prefix}attp
  ╠ Mas un texto corto
  ╠ ○ ${prefix}stickergif
  ╚ 6 segundos de video

◉ *CONVERTIDORES*
  ║
  ╠ ○ ${prefix}toimg
  ╠ De sticker a JPG
  ╠ ○ ${prefix}tomp3
  ╚ De video a MP3

◉ *AUDIO*
  ║
  ╠ ○ ${prefix}idioma
  ╚ ○ ${prefix}tts es (mas texto)

◉ *OTROS*
  ║
  ╠ ○ ${prefix}wame
  ╠ Link de Whatsapp
  ╠ ○ ${prefix}qrcode
  ╚ Coloca un texto

◉ *GRUPOS*
  ║
  ╠ ○ ${prefix}closegc
  ╠ Cerrar el grupo solo admins
  ╠ ○ ${prefix}opengc
  ╠ Abrir grupo solo admins
  ╠ ○ ${prefix}kickmenu
  ╠ Eliminar a un miembro 
  ╠ ○ ${prefix}promote
  ╠ Dar admin a un miembro
  ╠ ○ ${prefix}demote
  ╠ Quitar el admin
  ╠ ○ ${prefix}linkgc
  ╠ Link del grupo
  ╠ ○ ${prefix}todos
  ╚ Nombra a todos los del grupo

Para usar estas funciones el bot necesita admin
  
◉ *NSWF* 
  ║
  ╚ ○ ${prefix}nsfwmenu

Para activar los NSFW coloque el siguiente comando ${prefix}nsfw 1 y para desactivar los NSFW coloque ${prefix}nsfw 0


No te olvides de seguirme en instagram flaco ;)


ву ѕнαη∂υу


⌜ *ごきげんよう :)* ⌟ 
`
}

exports.help = help
