const shantera = (prefix, pushname) => {
    return `*Palabras especificas para que el bot interactue con ustedes*


todo bien
buenos dias
bot gay
gracias
hola
fua
corte
gaspi buenos dias 
gaspi me saludas
gaspi y las minitas
gaspi todo bien
me quiero suicidar
gaspi ya no aguanto
contate algo bot
sexo
momento epico
el bot del orto no funciona
epicardo
insta de la minita
una mierda de bot
ultimo momento
nefasto
paraguayo
bot de mierda
venezolano
gaspi corte
ya me voy a dormir
calefon
apurate bot
un chino
no funciona
boliviano
enano


_*Ojito escribe tal y como esta en el mensaje*_

ву ѕнαη∂υу`

}

exports.shantera = shantera
