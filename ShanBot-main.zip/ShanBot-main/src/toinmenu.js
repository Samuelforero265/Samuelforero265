const toinmenu = (prefix, pushname) => {
    return `◪ *Comandos de Shan*
    │
    ├─ ❏ ${prefix}setprefix
    ├─ ❏ ${prefix}block
    ├─ ❏ ${prefix}bc
    ├─ ❏ ${prefix}bcgc
    └─ ❏ ${prefix}clearall`

}

exports.toinmenu = toinmenu